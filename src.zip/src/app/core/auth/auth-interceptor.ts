import { Injectable } from '@angular/core';
import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Auth } from './auth';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(Auth);

  // Ne pas intercepter le login
  if (req.url.includes('/login')) {
    return next(req);
  }

  const authHeader = auth.getAuthHeader();
  if (authHeader) {
    const cloned = req.clone({
      setHeaders: { Authorization: authHeader }
    });
    return next(cloned);
  }

  return next(req);
};
