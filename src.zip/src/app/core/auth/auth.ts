import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class Auth {
  private apiUrl = 'http://localhost:8080'; // backend Spring Boot
  private _isLoggedIn = signal(false);
  private _username = signal<string | null>(null);
  private _password: string | null = null;

  constructor(private http: HttpClient, private router: Router) {}

  isLoggedIn() {
    return this._isLoggedIn.asReadonly();
  }

  username() {
    return this._username.asReadonly();
  }

  login(username: string, password: string) {
    const headers = new HttpHeaders({
      Authorization: 'Basic ' + btoa(username + ':' + password)
    });

    return this.http.get(this.apiUrl + '/api/me', { headers }).subscribe({
      next: () => {
        this._username.set(username);
        this._password = password;
        this._isLoggedIn.set(true);
        this.router.navigateByUrl('/');
      },
      error: () => {
        this._isLoggedIn.set(false);
        this._username.set(null);
        this._password = null;
      }
    });
  }

  logout() {
    this._isLoggedIn.set(false);
    this._username.set(null);
    this._password = null;
    this.router.navigateByUrl('/login');
  }

  getAuthHeader(): string | null {
    if (this._username() && this._password) {
      return 'Basic ' + btoa(this._username() + ':' + this._password);
    }
    return null;
  }
}
