import { Routes } from '@angular/router';
import { Login } from './pages/login/login';
import { AuthGuard } from './core/auth/auth-guard';

export const routes: Routes = [
  { path: 'login', component: Login },
  {
    path: '',
    canActivate: [AuthGuard],
    children: [
      // tes futures routes protégées (home, images, etc.)
    ]
  },
  { path: '**', redirectTo: '' }
];
